Rent & Electricity Tracker Android project

Features:
- Single home/room
- Rent amount entered manually each month
- Electricity bill amount entered manually
- Previous/current meter readings and unit estimate at editable rate (default ₹8/unit)
- Paid / unpaid / partial payment status
- Monthly history, edit/delete, yearly filter
- On-device browser storage via Android WebView localStorage
- CSV export and JSON backup/restore

Build APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync; use JDK 17 and install Android SDK platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.

This archive contains Android source project files, not a compiled APK. No Android SDK/Gradle installation was available in the generation environment to compile the APK here.
